﻿using System.ComponentModel.DataAnnotations;

namespace InventoryManagementProject.Models
{
    public class Products
    {
        [Key]
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string ProductCategory { get; set; }
        public float ProductPrice { get; set; }
        public int Stock { get; set; }
    }
}
